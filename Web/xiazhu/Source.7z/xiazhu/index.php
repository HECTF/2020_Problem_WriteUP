<!DOCTYPE html>
<html>
	<head><title>先提交试试</title></head>
	<body>
		<form action="index.php" method="post" >
			username:
			<input type='text' name="usname"  >
			<br>
			password:
			<input type='password' name="pswd" >
			<br>
			<span style="opacity: 1">
			<input  disabled='' type="submit" value="submit">
			</span>
		</form>
	</body>
</html>
<?php

	$servername="localhost";
	$db_usname="admin";
	$db_dbname="ctf";
	
	
	error_reporting(0);
	
	if(!isset($_POST['usname'])||!isset($_POST["pswd"])){
		die("你怎么能还不提交，你在想啥！");
	}
	$username=$_POST['usname'];
	$password=$_POST["pswd"];
	waf($username);
	waf($password);
	function waf($str)
	{
	$filter = 'outfile|readfile|load_file|sleep|delete|insert|update|updataxml|extractvalue|when|\^';
	if(preg_match('/'. $filter .'/i', $str)){
		die('也许你的思路没啥问题，但我总不能白给吧');
	}
	}
	
	$conn=mysqli_connect($servername,$db_usname,"",$db_dbname);
	if (mysqli_connect_errno($conn)) { 
    die("连接 MySQL 失败: " . mysqli_connect_error()); 
	}else{
		
		$sql="SELECT username, password FROM users WHERE username='".$_POST['usname']."'and password='".$_POST['pswd']."' LIMIT 0,1";
		$result=mysqli_query($conn,$sql);
		if($result)
		{
			echo "你以为我会给你数据？！hahaha";
		}
		else
		{	
			echo "你以为我会给你数据？！hahaha";
		}
		mysqli_close($conn);
	}

	
?>
