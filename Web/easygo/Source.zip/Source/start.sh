whoami&&cd /go&&go run src/main.go src/functions.go src/model.go src/routes.go 
