package main

import (
	"fmt"
	"html/template"
	"io/ioutil"
	"net/http"
)


func index(w http.ResponseWriter, r *http.Request) {
	t, _ := template.ParseFiles("index.gtpl")
	t.Execute(w,nil)
	return;
}

func login(w http.ResponseWriter, r *http.Request) {
	if r.Method=="POST"{
		r.ParseForm()
		if r.Form["username"]==nil && r.Form["password"]==nil{
			fmt.Fprint(w,"username and password is required")
			return
		}
		a := r.Form["username"][0]
		fmt.Println(a)
        if r.Form["username"][0]=="admin"{
        	fmt.Fprint(w,"you are not admin")
        	return
		}
		User:=Users{
			Username: r.Form["username"][0],
			Password: r.Form["password"][0],
		}
        setCookie(w,r,cookieEncode(serialize(User)))
		fmt.Fprint(w,"<script>window.location.href='/home'</script>")
	}else{
		fmt.Fprint(w,"Method not allowed")
		return
	}
}
func home(w http.ResponseWriter,r *http.Request){
	if getCookie(r)!=nil {
		fmt.Println(getCookie(r))
		User:=unseralize(cookieDecode(getCookie(r).(string)))
		if User.Username=="admin"{
			flag ,_:= ioutil.ReadFile("/flag")
			fmt.Fprintln(w,string(flag))
		}else{
			fmt.Fprint(w,"only admin can see")
		}
	}else{
		fmt.Fprint(w,"<script>alert('Login first my baby');</script>")
		return
	}
}
