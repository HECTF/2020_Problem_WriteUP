package main

type Users struct{
	Username string
	Password string
}

