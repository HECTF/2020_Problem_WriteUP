package main

import (
	"bytes"
	"crypto/md5"
	"encoding/base64"
	"encoding/gob"
	"encoding/hex"
	"net/http"
	"os"
	"time"
)

func PathExists(path string) (bool, error) {
	_, err := os.Stat(path)
	if err == nil {
		return true, nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}
	return false, err
}
func fileExist(filename string) bool {
	_, err := os.Stat(filename)
	return err == nil || os.IsExist(err)
}
func Md5(s string) string {
	h := md5.New()
	h.Write([]byte(s))
	return hex.EncodeToString(h.Sum(nil))
}
func getCookie(r *http.Request) interface{}{
	cookie, err := r.Cookie("cookie")
	if err==nil{
		return cookie.Value
	}else{
		return nil
	}
}
func setCookie(w http.ResponseWriter,r *http.Request,value string){
	expiration := time.Now()
	expiration = expiration.AddDate(1, 0, 0)
	cookie := http.Cookie{Name: "cookie", Value: value, Expires: expiration}
	http.SetCookie(w, &cookie)
}
func serialize(instance Users) []byte{
	var result bytes.Buffer
	encoder := gob.NewEncoder(&result)
	encoder.Encode(instance)
	userBytes := result.Bytes()
	return userBytes
}
func unseralize(data []byte) Users{
	var account Users
	decoder := gob.NewDecoder(bytes.NewReader(data))
	decoder.Decode(&account)
	return account
}
//序列化成[]byte 然后encode成string设置上去  把string decode成[byte]然后反序列化
//流程：string的cookie->解密成[]byte->反序列化->成为Users对象   序列化的[]byte->加密->放cookie里
func cookieEncode(data []byte) string{
	return base64.StdEncoding.EncodeToString(data)
}
func cookieDecode(data string) []byte{
	bytesData, _ := base64.StdEncoding.DecodeString(data)
	return bytesData
}