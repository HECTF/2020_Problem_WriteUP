#!/bin/bash

sleep 1
if [[ -f /flag.sh ]]; then
	source /flag.sh
fi

echo "0 17 2 8 * /bin/php /very_g00d_Y0u_got_it.php">> /etc/crontab
apache2-foreground
