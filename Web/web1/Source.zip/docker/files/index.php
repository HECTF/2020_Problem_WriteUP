<html>
<?php

if ($_POST['a'] !== $_POST['b'] && md5($_POST['a']) === md5($_POST['b'])) {
    echo ("You need the file is ./3b8cf4731c36d20776c76e20f9c774c7.php");
} else {
    echo ("nonono ，once again！");
}

?>
<!--
if ($_POST['a'] !== $_POST['b'] && md5($_POST['a']) === md5($_POST['b'])) {
echo ("You need the file is xxx");
} else {
echo ("nonono ，once again！");
}
flag不在/flag中哦，你应该找找奇奇怪怪的文件名
-->
</html>