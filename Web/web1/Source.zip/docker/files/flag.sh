#!/bin/bash

echo "flag{41e000b2-dadc-11ea-917a-9b59aa93fd1b}" > /flag
chmod -R 744 /flag
mv /flag /Zmw0Z2dnZ2dnZ2dnZ2dnCg
echo "你要的flag不在这里"> /flag
rm -f /flag.sh
