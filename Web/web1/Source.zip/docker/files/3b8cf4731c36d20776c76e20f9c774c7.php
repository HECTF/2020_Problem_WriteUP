<html>
@$data=$_POST['data'];
$file=$_POST['file'];
if($file!="/xxx")
die("你需要知道写入的文件名！！！！！我猜你知道到这个文件叫什么,记得加上绝对路径");
if(';' === preg_replace('/[^\W]+\((?R)?\)/', '', $data)) {
echo "great!!!!你需要看看源码";
file_put_contents($file,"<?php ".\$data." ?>");
}

<?php
@$data=$_POST['data'];
$file=$_POST['file'];
if($file!="/very_g00d_Y0u_got_it.php")
    die("你需要知道写入的文件名！！！！！我猜你知道到这个文件叫什么,记得加上绝对路径");

if (!preg_match('/et|na|info|dec|bin|hex|oct|pi|log/i', $data))
    die("nonono ");
if(';' === preg_replace('/[^\W]+\((?R)?\)/', '', $data)) {
    echo "great!!!!";
    @file_put_contents($file,"<?php ".$data." ?>");
    //你想要的文件是   Zmw0Z2dnZ2dnZ2dnZ2dnCg
}

?>

</html>>