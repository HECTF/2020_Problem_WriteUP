#!/bin/bash

export FLAG=flag{04f3eaef-ec7c-4a44-8b54-062cd19295f3}

echo $FLAG > /flag
export FLAG=no
FLAG=no

rm -f /flag.sh
